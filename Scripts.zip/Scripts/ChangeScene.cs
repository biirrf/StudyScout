// Steven Hankinson 21129647
// Created by Following "Unity Change Scene With Button - EASIEST Method" video by Unitips uploaded on 28th October 2021
// https://www.youtube.com/watch?v=zQH7RRb3CnY

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

}
